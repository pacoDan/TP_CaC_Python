docker exec -it $(cat CONTAINER_ID) /bin/bash
